<?php
session_start();
require_once(dirname(__FILE__) . '/db_connection.php');

$conn = new mysqli($DB_SERVER, $DB_USER, $DB_PASSWORD, $DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch products from the database
$sql = "SELECT `product_id`, `product_name`, `category`, `price`, `stock`, `description`, `image_url`, `created_at`, `updated_at` FROM `products` WHERE 1";
$result = $conn->query($sql);
?>

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product Details</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="dist/css/products.css">

   <script>
        document.addEventListener('DOMContentLoaded', function() {
            var viewMoreBtns = document.querySelectorAll('.view-more-btn');
            var addToCartBtns = document.querySelectorAll('.add-to-cart-btn');
            var popup = document.querySelector('.popup');
            var popupClose = document.querySelector('.popup-close');

            viewMoreBtns.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var productImage = this.closest('.product-card').querySelector('.product-image img').src;
                    var productTitle = this.closest('.product-card').querySelector('h3').textContent;
                    var productPrice = this.closest('.product-card').querySelector('.price').textContent;
                    var productDescription = this.closest('.product-card').querySelector('.description').value;

                    var popupImage = popup.querySelector('.popup-image img');
                    var popupTitle = popup.querySelector('.popup-info h2');
                    var popupPrice = popup.querySelector('.popup-info .price');
                    var popupDescription = popup.querySelector('.popup-info .description');

                    popupImage.src = productImage;
                    popupTitle.textContent = productTitle;
                    popupPrice.textContent = productPrice;
                    popupDescription.textContent = productDescription;

                    popup.classList.add('visible');
                });
            });

            addToCartBtns.forEach(function(btn) {
                btn.addEventListener('click', function() {
                    var productTitle = this.closest('.product-card').querySelector('h3').textContent;
                    alert("You added " + productTitle + " to your cart!");
                });
            });

            popup.addEventListener('click', function(event) {
                if (event.target === popup || event.target === popupClose) {
                    popup.classList.remove('visible');
                }
            });
        });
    </script>
</head>
<body>
    <div class="navbar">
        <img src="dist/images/logo.jpg" alt="" class="logo1">
        <h1>Vishu_Craft</h1>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="product.php">Product</a></li>
            <li><a href="Services.php">Services</a></li>
            <li><a href="About-Us.php">About Us</a></li>
            <li><a href="Contact-Us.php">Contact Us</a></li>
            <?php if (isset($_SESSION['username'])): ?>
                <li><a href="#"><?php echo htmlspecialchars($_SESSION['username']); ?></a></li>
                <li><a href="logout.php">Logout</a></li>
            <?php else: ?>
                <li><a href="login.php">Login</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <div class="head">OUR PRODUCTS</div>
    <div class="container">
        <div class="products">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <img src="admin/<?php echo htmlspecialchars($row['image_url']); ?>" alt="<?php echo htmlspecialchars($row['product_name']); ?>">
                        </div>
                        <div class="product-info">
                            <h3><?php echo htmlspecialchars($row['product_name']); ?></h3>
                            <div class="price">Rs.<?php echo number_format($row['price'], 2); ?></div>
                            <input type="hidden" class= "description" value="<?php echo htmlspecialchars($row['description']); ?>">
                            <div class="rating">★★★★☆</div> <!-- Add logic for rating if needed -->
                            <button class="view-more-btn">View More</button>
                            <button class="add-to-cart-btn">Add to Cart</button>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No products available.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="popup">
        <div class="popup-content">
            <button class="popup-close">Close</button>
            <div class="popup-image">
                <img src="" alt="Product Image">
            </div>
            <div class="popup-info">
                <h2>Product Title</h2>
                <div class="price">$99.99</div>
                <div class="description">This is a detailed description of the product. It provides essential features, benefits, and any other important information that helps customers understand what they are purchasing.</div>
                <div class="popup-buttons">
                    <button class="add-to-cart-btn">Add to Cart</button>
                </div>
            </div>
        </div>
    </div>

    <?php
    // Close the database connection
    $conn->close();
    ?>
</body>
</html>