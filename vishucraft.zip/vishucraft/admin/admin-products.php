<?php
require_once(dirname(__FILE__) . '/db_connection.php');

session_start();

// Database connection
$conn = new mysqli($DB_SERVER, $DB_USER, $DB_PASSWORD, $DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $productId = isset($_POST['product_id']) ? trim($_POST['product_id']) : '';

    if (!empty($productId)) {
        if ($stmt = $conn->prepare("DELETE FROM products WHERE product_id = ?")) {
            $stmt->bind_param("i", $productId);

            if ($stmt->execute()) {
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            } else {
                echo "Error deleting product: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error preparing statement: " . $conn->error;
        }
    } else {
        echo "Invalid product ID.";
    }
}


// Pagination setup
$rowsPerPage = 6;
$currentPage = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($currentPage - 1) * $rowsPerPage;

// Get total products count
$totalQuery = "SELECT COUNT(*) AS total FROM products";
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalProducts = $totalRow['total'];
$totalPages = ceil($totalProducts / $rowsPerPage);

// Fetch paginated products
$query = "SELECT `product_id`, `image_url`, `product_name`, `category`, `stock`, `price`
          FROM `products`
          LIMIT $rowsPerPage OFFSET $offset";
$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);
}

// Close connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Products</title>
  
    <!-- google icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">

    <!-- css stylesheet -->
    <link rel="stylesheet" href="../dist/css/admin.css">
    <link rel="stylesheet" href="../dist/css/admin-extra.css">
</head>

<body>
  
    <!-- for header part -->
    <header>

        <div class="logosec">
            <img src="../dist/images/logo.jpg" alt="Logo" class="logo-img">
            <span class="material-icons-sharp icn menuicn" id="menuicn">menu</span>
        </div>

        <div class="logo">Vishu Craft</div>

        <div class="username"> 
            <?php echo htmlspecialchars($_SESSION['username']); ?>
        </div>

    </header>

    <div class="main-container">
        <div class="navcontainer">
            <nav class="nav">
                <div class="nav-upper-options">
                    <div class="nav-option ">
                        <span class="material-icons-sharp" class="nav-img">dashboard</span>
                        <h3><a href="admin-dashboard.php">Dashboard</a></h3>
                    </div>

                    <div class="nav-option option3">
                        <span class="material-icons-sharp nav-img">person</span>
                        <h3><a href="admin-customers.php">Customers</a></h3>
                    </div>

                    <div class="option2 nav-option option1">
                    <span class="material-icons-sharp nav-img">inventory_2</span>
                        <h3><a href="admin-products.php">Products</a></h3>
                    </div>

                    <div class="nav-option logout">
                        <span class="material-icons-sharp nav-img">logout</span>
                        <h3><a href="logout.php" style="text-decoration: none; color:black;">Logout</a></h3>
                    </div>

                </div>
            </nav>
        </div>

        <!-- Main Content -->
        <main>
                <h1>Products List (Total: <?php echo $totalProducts; ?>)</h1>
                <!-- Products Table -->
                <div class="customer-list">
                    <div style="display: flex; align-items: center;">
                        <button class="refresh-button" onclick="window.location.reload();">
                            <span class="material-icons-sharp">refresh</span>
                        </button>
                        <button id="add-product-btn" class="refresh-button" onclick="openAddProductModal()">
                            <span class="material-icons-sharp">add</span>
                        </button>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Product Image</th>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Stock Quantity</th>
                                <th>Price (Per Item)</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $productId = htmlspecialchars($row['product_id']);;
                                    $productImage = htmlspecialchars($row['image_url']);
                                    $productName = htmlspecialchars($row['product_name']);
                                    $category = htmlspecialchars($row['category']);
                                    $stockQuantity = htmlspecialchars($row['stock']);
                                    $price = htmlspecialchars($row['price']);

                                    echo "<tr>";
                                    echo "<td>$productId</td>";
                                    echo "<td><center><img src='$productImage' alt='Product Photo' style='width: 40px; height: 40px; border-radius: 50%;'></center></td>";
                                    echo "<td>$productName</td>";
                                    echo "<td>$category</td>";
                                    echo "<td>$stockQuantity</td>";
                                    echo "<td>Rs.$price</td>";
                                    echo "<td>
                                        <button type='button' onclick='openDeleteModal(\"$productId\")' class='delete-button' style='background-color: #e74c3c; color: white; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; font-size: 14px;'>Delete</button>
                                    </td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No products found</td></tr>";
                            }
                            $result->free();
                            ?>

                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="pagination">
                        <?php if ($currentPage > 1): ?>
                            <a href="?page=<?php echo $currentPage - 1; ?>" class="prev-page">Previous</a>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <a href="?page=<?php echo $i; ?>" class="<?php echo ($i == $currentPage) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                        <?php endfor; ?>

                        <?php if ($currentPage < $totalPages): ?>
                            <a href="?page=<?php echo $currentPage + 1; ?>" class="next-page">Next</a>
                        <?php endif; ?>
                    </div>
                </div>

            </main>
    </div>

<!-- Add Product Modal Popup -->
<div id="add-product-modal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close-add-product">&times;</span>
        <div class="content">
            <h2>Add New Product</h2>
            <form id="add-product-form" action="add_product.php" method="POST" enctype="multipart/form-data">
                <center><img src="../dist/images/plus.png" class="profile-logo" id="product-pic" style="border-radius: 50%; margin: 0 auto 10px; width: 100px; height: 100px;" alt="Product Image Preview"></center>
                <label for="input-file" style="display: block; width: 250px; text-align: center; background-color: var(--color-danger); color: var(--color-dark); padding: 12px; margin: 10px auto; border-radius: 5px; cursor: pointer;">Upload Product Image</label>
                <input type="file" accept="image/jpeg, image/png, image/jpg" id="input-file" name="product_image" style="display: none;">
                <span id="product-image-msg"></span>

                <label for="product_name">Product Name:</label>
                <input type="text" id="product_name" name="product_name" required>
                <span id="product-name-msg"></span>

                <label for="category">Category:</label>
                <input type="text" id="category" name="category" required>
                <span id="category-msg"></span>

                <label for="stockQuantity">Stock Quantity:</label>
                <input type="number" id="stockQuantity" name="stock_quantity" required>
                <span id="stock-quantity-msg"></span>

                <label for="price">Price:</label>
                <input type="number" step="0.01" id="price" name="price" required>
                <span id="price-msg"></span>

                <label for="description">Description:</label>
                <textarea id="description" name="description" rows="4" required></textarea>
                <span id="description-msg"></span>

                <button type="button" id="cancel-add-product-btn" class="cancel-add-product-btn">Cancel</button>
                <button type="submit" class="add-product-btn">Add Product</button>
            </form>
        </div>
    </div>
</div>
<!-- End of Add Product Modal Popup -->

<!-- Delete Modal Popup -->
<div id="delete-modal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close">&times;</span>
        <div class="content">
            <p>Are you sure you want to delete this Product?</p>
            <form id="delete-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="product_id" id="modal-product-id">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="delete-button" style="background-color: var(--color-danger);">Delete</button>
                <button type="button" id="cancel-btn">Cancel</button>
            </form>
        </div>
    </div>
</div>

    <script src="../dist/js/main.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // ADD PRODUCT MODAL
            const addProductModal = document.getElementById('add-product-modal');
            const openAddProductModalBtn = document.getElementById('add-product-btn'); // Button to open modal
            const closeAddProductModal = document.querySelector('#add-product-modal .close-add-product');
            const cancelAddProductBtn = document.getElementById('cancel-add-product-btn');

            // Open Add Product Modal
            if (openAddProductModalBtn) {
                openAddProductModalBtn.addEventListener('click', function() {
                    addProductModal.style.display = 'block';
                });
            }

            // Close Add Product Modal
            if (closeAddProductModal) {
                closeAddProductModal.addEventListener('click', function() {
                    addProductModal.style.display = 'none';
                });
            }

            if (cancelAddProductBtn) {
                cancelAddProductBtn.addEventListener('click', function() {
                    addProductModal.style.display = 'none';
                });
            }

            window.addEventListener('click', function(event) {
                if (event.target === addProductModal) {
                    addProductModal.style.display = 'none';
                }
            });

            // DELETE MODAL
            const deleteModal = document.getElementById('delete-modal');
            const closeModal = document.querySelector('#delete-modal .close');
            const cancelBtn = document.getElementById('cancel-btn');
            const deleteForm = document.getElementById('delete-form');
            const modalProductId = document.getElementById('modal-product-id');

            // Open Delete Modal and Set Product ID
            window.openDeleteModal = function(productId) {
                modalProductId.value = productId;
                deleteModal.style.display = 'block';
            };

            // Close Delete Modal
            if (closeModal) {
                closeModal.addEventListener('click', function() {
                    deleteModal.style.display = 'none';
                });
            }

            if (cancelBtn) {
                cancelBtn.addEventListener('click', function() {
                    deleteModal.style.display = 'none';
                });
            }

            window.addEventListener('click', function(event) {
                if (event.target === deleteModal) {
                    deleteModal.style.display = 'none';
                }
            });
        });
        let profilePic = document.getElementById("product-pic");
        let inputFile = document.getElementById("input-file");

        inputFile.onchange = function() {
            profilePic.src = URL.createObjectURL(inputFile.files[0]);
        };
    </script>
</body>
</html>
