<?php
require_once(dirname(__FILE__) . '/db_connection.php'); // Ensure this file contains your database connection details

// Database connection
$mysqli = new mysqli($DB_SERVER, $DB_USER, $DB_PASSWORD, $DB_NAME);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve and sanitize input values
    $productName = $mysqli->real_escape_string(trim($_POST['product_name']));
    $category = $mysqli->real_escape_string(trim($_POST['category']));
    $stockQuantity = (int)$_POST['stock_quantity'];
    $price = (float)$_POST['price'];
    $description = $mysqli->real_escape_string(trim($_POST['description']));

    // Generate a unique product_id (assuming it's auto-increment in the database)
    // You can comment out this section if product_id is auto-incremented in the database
    $productQuery = "SELECT MAX(product_id) AS max_product_id FROM products";
    $maxProductIdResult = $mysqli->query($productQuery);
    $row = $maxProductIdResult->fetch_assoc();
    $maxProductId = $row['max_product_id'];
    $newProductId = $maxProductId + 1; // Only needed if product_id is not auto-incremented

    // Generate a unique image name based on product_id and product_name
    $sanitizedProductName = preg_replace('/[^a-zA-Z0-9]/', '_', $productName); // Sanitize product name for file naming
    $imageExtension = pathinfo($_FILES['product_image']['name'], PATHINFO_EXTENSION);
    $imageName = $newProductId . '_' . $sanitizedProductName . '.' . $imageExtension;
    $productImagePath = 'dist/uploads/products/' . $imageName; // Path for storing image

    // Handle image upload
    if (isset($_FILES['product_image']) && $_FILES['product_image']['error'] === UPLOAD_ERR_OK) {
        $imageTmpName = $_FILES['product_image']['tmp_name'];

        // Ensure the target directory exists
        if (!is_dir(dirname($productImagePath))) {
            mkdir(dirname($productImagePath), 0755, true); // Create directory if it doesn't exist
        }

        // Move the uploaded file to the desired directory
        if (!move_uploaded_file($imageTmpName, $productImagePath)) {
            echo "Failed to move uploaded file.";
            exit();
        }
    } else {
        $productImagePath = ''; // Set to empty if no image uploaded
    }

    // Prepare and execute the INSERT query
    $stmt = $mysqli->prepare("INSERT INTO products (product_id, product_name, category, price, stock, description, image_url, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("issdiss", $newProductId, $productName, $category, $price, $stockQuantity, $description, $productImagePath);

    if ($stmt->execute()) {
        header("Location: " . $_SERVER['HTTP_REFERER']); // Redirect back to the previous page
        exit();
    } else {
        echo "Error adding product: " . $stmt->error;
    }

    $stmt->close();
}

$mysqli->close();
?>
