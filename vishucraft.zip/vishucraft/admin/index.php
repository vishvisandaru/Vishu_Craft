<?php
// Start the session
session_start();

// Include database connection
include 'db_connection.php';

// Initialize variables
$username = $password = "";
$login_error = "";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Login process
    if (isset($_POST['login'])) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        // Check credentials
        if ($stmt = $conn->prepare("SELECT * FROM admin WHERE username = ?")) {
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    // Set session variables
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['Admin_ID'] = $user['admin_id']; // Assuming you have an admin_id field
                    $_SESSION['Login_Type'] = 'admin'; // Track user type

                    // Redirect to admin Dashboard page after successful login
                    header("Location: admin-dashboard.php");
                    exit();
                } else {
                    $login_error = "Invalid username or password.";
                }
            } else {
                $login_error = "Invalid username or password.";
            }
            $stmt->close();
        } else {
            $login_error = "Database error: " . $conn->error;
        }
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <!-- Font Awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- CSS stylesheet -->
    <link rel="stylesheet" href="../dist/css/login-styles.css">
</head>

<body>

    <div class="container" id="container" style="width: 450px; padding: 0 20px">
        <div class="sign-in-container">
            <form id="loginForm" action="" method="POST"> 
                <h1 style="margin-bottom: 35px;">Admin Login</h1>
                <div class="infield">
                    <input type="text" placeholder="Username" name="username" id="loginUname" required/> 
                    <label></label>
                </div>
                <div class="infield">
                    <input type="password" placeholder="Password" name="password" id="loginPsw" required/> 
                    <label></label>
                </div>
                <button type="submit" name="login">Sign In</button> 
                <?php if ($login_error): ?>
                    <div style="color: red; margin-top: 10px;"><?php echo $login_error; ?></div>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <footer>
    </footer>
    
    <!-- JS code -->
    <script src="../dist/js/formValidation.js"></script>
</body>
</html>
