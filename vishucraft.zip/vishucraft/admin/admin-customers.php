<?php
require_once(dirname(__FILE__) . '/db_connection.php');

session_start();

// Database connection
$conn = new mysqli($DB_SERVER, $DB_USER, $DB_PASSWORD, $DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $userId = isset($_POST['user_id']) ? trim($_POST['user_id']) : '';

    if (!empty($userId)) {
        if ($stmt = $conn->prepare("DELETE FROM users WHERE id = ?")) {
            $stmt->bind_param("i", $userId);

            if ($stmt->execute()) {
                header("Location: " . $_SERVER['PHP_SELF']);
                exit();
            } else {
                echo "Error deleting user: " . $stmt->error;
            }
            $stmt->close();
        } else {
            echo "Error preparing statement: " . $conn->error;
        }
    } else {
        echo "Invalid user ID.";
    }
}

// Pagination setup
$rowsPerPage = 6;
$currentPage = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($currentPage - 1) * $rowsPerPage;

// Get total users count
$totalQuery = "SELECT COUNT(*) AS total FROM users";
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalUsers = $totalRow['total'];
$totalPages = ceil($totalUsers / $rowsPerPage);

// Fetch paginated users
$query = "SELECT `id`, `name`, `username`, `email`, `password` FROM `users` LIMIT $rowsPerPage OFFSET $offset";
$result = $conn->query($query);


if (!$result) {
    die("Query failed: " . $conn->error);
}

// Fetch results into an array for displaying
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Products</title>
  
    <!-- google icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">

    <!-- css stylesheet -->
    <link rel="stylesheet" href="../dist/css/admin.css">
    <link rel="stylesheet" href="../dist/css/admin-extra.css">
</head>

<body>
  
    <!-- for header part -->
    <header>

        <div class="logosec">
            <img src="../dist/images/logo.jpg" alt="Logo" class="logo-img">
            <span class="material-icons-sharp icn menuicn" id="menuicn">menu</span>
        </div>

        <div class="logo">Vishu Craft</div>

        <div class="username"> 
            <?php echo htmlspecialchars($_SESSION['username']); ?>
        </div>

    </header>

    <div class="main-container">
        <div class="navcontainer">
            <nav class="nav">
                <div class="nav-upper-options">
                    <div class="nav-option ">
                        <span class="material-icons-sharp" class="nav-img">dashboard</span>
                        <h3><a href="admin-dashboard.php">Dashboard</a></h3>
                    </div>

                    <div class="nav-option option3 option1">
                        <span class="material-icons-sharp nav-img">person</span>
                        <h3><a href="admin-customers.php">Customers</a></h3>
                    </div>

                    <div class="option2 nav-option">
                    <span class="material-icons-sharp nav-img">inventory_2</span>
                        <h3><a href="admin-products.php">Products</a></h3>
                    </div>

                    <div class="nav-option logout">
                        <span class="material-icons-sharp nav-img">logout</span>
                        <h3><a href="logout.php" style="text-decoration: none; color:black;">Logout</a></h3>
                    </div>

                </div>
            </nav>
        </div>

        <!-- Main Content -->
        <main>
            <h1>User List (Total: <?php echo $totalUsers; ?>)</h1>
            <!-- User Table -->
            <div class="customer-list">
                <div style="display: flex; align-items: center;">
                    <button class="refresh-button" onclick="window.location.reload();">
                        <span class="material-icons-sharp">refresh</span>
                    </button>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>User ID</th>
                            <th>Name</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        if ($users) {
                            foreach ($users as $row) {
                                $userId = htmlspecialchars($row['id']);
                                $name = htmlspecialchars($row['name']);
                                $username = htmlspecialchars($row['username']);
                                $email = htmlspecialchars($row['email']);

                                echo "<tr>";
                                echo "<td>$userId</td>";
                                echo "<td>$name</td>";
                                echo "<td>$username</td>";
                                echo "<td>$email</td>";
                                echo "<td>
                                    <button type='button' onclick='openDeleteModal(\"$userId\")' class='delete-button' style='background-color: #e74c3c; color: white; border: none; padding: 8px 12px; border-radius: 4px; cursor: pointer; font-size: 14px;'>Delete</button>
                                </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>No users found</td></tr>";
                        }
                        $result->free();
                    ?>
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="pagination">
                    <?php if ($currentPage > 1): ?>
                        <a href="?page=<?php echo $currentPage - 1; ?>" class="prev-page">Previous</a>
                    <?php endif; ?>

                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <a href="?page=<?php echo $i; ?>" class="<?php echo ($i == $currentPage) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                    <?php endfor; ?>

                    <?php if ($currentPage < $totalPages): ?>
                        <a href="?page=<?php echo $currentPage + 1; ?>" class="next-page">Next</a>
                    <?php endif; ?>
                </div>
            </div>
        </main>
        </div>


<!-- Delete Modal Popup -->
<div id="delete-modal" class="modal" style="display: none;">
    <div class="modal-content">
        <span class="close">&times;</span>
        <div class="content">
            <p>Are you sure you want to delete this User?</p>
            <form id="delete-form" action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="user_id" id="modal-user-id">
                <input type="hidden" name="action" value="delete">
                <button type="submit" class="delete-button" style="background-color: var(--color-danger);">Delete</button>
                <button type="button" id="cancel-btn">Cancel</button>
            </form>
        </div>
    </div>
</div>


    <script src="../dist/js/main.js"></script>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // DELETE MODAL
        const deleteModal = document.getElementById('delete-modal');
        const closeModal = document.querySelector('#delete-modal .close');
        const cancelBtn = document.getElementById('cancel-btn');
        const deleteForm = document.getElementById('delete-form');
        const modalUserId = document.getElementById('modal-user-id'); // Corrected from modal-product-id

        // Open Delete Modal and Set User ID
        window.openDeleteModal = function(userId) {
            modalUserId.value = userId; // Changed to modalUserId
            deleteModal.style.display = 'block';
        };

        // Close Delete Modal
        if (closeModal) {
            closeModal.addEventListener('click', function() {
                deleteModal.style.display = 'none';
            });
        }

        if (cancelBtn) {
            cancelBtn.addEventListener('click', function() {
                deleteModal.style.display = 'none';
            });
        }

        window.addEventListener('click', function(event) {
            if (event.target === deleteModal) {
                deleteModal.style.display = 'none';
            }
        });
    });
</script>

</body>
</html>
