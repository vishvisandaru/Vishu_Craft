<?php
require_once(dirname(__FILE__) . '/db_connection.php');

session_start();

// Database connection
$conn = new mysqli($DB_SERVER, $DB_USER, $DB_PASSWORD, $DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination setup
$rowsPerPage = 6;
$currentPage = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($currentPage - 1) * $rowsPerPage;

// Get total products count
$totalQuery = "SELECT COUNT(*) AS total FROM products";
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalProducts = $totalRow['total'];
$totalPages = ceil($totalProducts / $rowsPerPage);

// Get total users count
$totalQuery = "SELECT COUNT(*) AS total FROM users";
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalUsers = $totalRow['total'];
$totalPages = ceil($totalUsers / $rowsPerPage);

// Fetch paginated products
$query = "SELECT `product_id`, `image_url`, `product_name`, `category`, `stock`, `price`
          FROM `products`
          LIMIT $rowsPerPage OFFSET $offset";
$result = $conn->query($query);

if (!$result) {
    die("Query failed: " . $conn->error);
}

// Close connection
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
  
    <!-- google icons -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp" rel="stylesheet">

    <!-- css stylesheet -->
    <link rel="stylesheet" href="../dist/css/admin.css">
    <link rel="stylesheet" href="../dist/css/admin-extra.css">

</head>

<body>
  
    <!-- for header part -->
    <header>

        <div class="logosec">
            <img src="../dist/images/logo.jpg" alt="Logo" class="logo-img">
            <span class="material-icons-sharp icn menuicn" id="menuicn">menu</span>
        </div>

        <div class="logo">Vishu Craft</div>

        <div class="username"> 
            <?php echo htmlspecialchars($_SESSION['username']); ?>
        </div>

    </header>

    <div class="main-container">
        <div class="navcontainer">
            <nav class="nav">
                <div class="nav-upper-options">
                <div class="nav-upper-options">
                    <div class="nav-option option1">
                        <span class="material-icons-sharp" class="nav-img">dashboard</span>
                        <h3><a href="admin-dashboard.php">Dashboard</a></h3>
                    </div>

                    <div class="nav-option option3">
                        <span class="material-icons-sharp nav-img">person</span>
                        <h3><a href="admin-customers.php">Customers</a></h3>
                    </div>

                    <div class="option2 nav-option">
                    <span class="material-icons-sharp nav-img">inventory_2</span>
                        <h3><a href="admin-products.php">Products</a></h3>
                    </div>

                    <div class="nav-option logout">
                        <span class="material-icons-sharp nav-img">logout</span>
                        <h3><a href="logout.php" style="text-decoration: none; color:black;">Logout</a></h3>
                    </div>

                </div>
            </nav>
        </div>
        <div class="main">

            <div class="box-container">
                <div class="box box1">
                    <div class="text">
                        <h2 class="topic-heading"><?php echo $totalUsers; ?></h2>
                        <h2 class="topic">All Customers</h2>
                    </div>
                        <span class="material-icons-sharp icon">group</span>                
                </div>

                <div class="box box2">
                    <div class="text">
                        <h2 class="topic-heading"><?php echo $totalProducts; ?></h2>
                        <h2 class="topic">All Products</h2>
                    </div>
                    <span class="material-icons-sharp icon">inventory_2</span>                
                </div>
        </div>

        <main>
                <!-- Products Table -->
                <div class="customer-list">
                    <div style="display: flex; align-items: center;">
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Product ID</th>
                                <th>Product Image</th>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Stock Quantity</th>
                                <th>Price (Per Item)</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    $productId = htmlspecialchars($row['product_id']);;
                                    $productImage = htmlspecialchars($row['image_url']);
                                    $productName = htmlspecialchars($row['product_name']);
                                    $category = htmlspecialchars($row['category']);
                                    $stockQuantity = htmlspecialchars($row['stock']);
                                    $price = htmlspecialchars($row['price']);

                                    echo "<tr>";
                                    echo "<td>$productId</td>";
                                    echo "<td><center><img src='$productImage' alt='Product Photo' style='width: 40px; height: 40px; border-radius: 50%;'></center></td>";
                                    echo "<td>$productName</td>";
                                    echo "<td>$category</td>";
                                    echo "<td>$stockQuantity</td>";
                                    echo "<td>Rs.$price</td>";
                                    echo "</tr>";
                                }
                            } else {
                                echo "<tr><td colspan='7'>No products found</td></tr>";
                            }
                            $result->free();
                            ?>

                        </tbody>
                    </table>

                    <!-- Pagination -->
                    <div class="pagination">
                        <?php if ($currentPage > 1): ?>
                            <a href="?page=<?php echo $currentPage - 1; ?>" class="prev-page">Previous</a>
                        <?php endif; ?>

                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <a href="?page=<?php echo $i; ?>" class="<?php echo ($i == $currentPage) ? 'active' : ''; ?>"><?php echo $i; ?></a>
                        <?php endfor; ?>

                        <?php if ($currentPage < $totalPages): ?>
                            <a href="?page=<?php echo $currentPage + 1; ?>" class="next-page">Next</a>
                        <?php endif; ?>
                    </div>
                </div>

            </main>
    </div>


    <script src="../dist/js/main.js"></script>
</body>
</html>
