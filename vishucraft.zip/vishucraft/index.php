<?php
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vishu Craft</title>
    <link rel="stylesheet" href="dist/css/style.css">
</head>
<body>
    <div class="banner">
        <div class="navbar">
            <img src="dist/images/logo.jpg" alt="" class="logo1">
            <h1>Vishu_Craft</h1>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="product.php">Product</a></li>
                <li><a href="Services.php">Services</a></li>
                <li><a href="About-Us.php">About Us</a></li>
                <li><a href="Contact-Us.php">Contact Us</a></li>
                <?php if (isset($_SESSION['username'])): ?>
                    <li><a href="#"><?php echo htmlspecialchars($_SESSION['username']); ?></a></li>
                    <li><a href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li><a href="login.php">Login</a></li>
                <?php endif; ?>
                </ul>
        </div>
        <div class="container">
            <div class="img-container">
                <img src="dist/images/backg.jpeg" alt="">
                <img src="dist/images/2.jpg" alt="">
                <img src="dist/images/back.png" alt="">
            </div>
        </div>
        <div class="content">
            <h1>Decoration Your Dreams</h1>
            <p>Craft Your Dream is a Non-profit
                 Organization Dedicated to Coaching Dreamers to 
                 achieve big goals and lead well for a life of 
                 impact.</p>
                 <div>
                    <button><span></span><a href="login.php">login</a></button>
                    <button><span></span><a href="product.php" >Our Product</a></button>
                 </div>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>