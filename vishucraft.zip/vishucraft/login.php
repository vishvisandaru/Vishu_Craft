<?php
// Start the session
session_start();

// Include database connection
include 'db_connection.php';

// Initialize variables
$name = $username = $email = $password = "";
$register_error = $login_error = "";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Registration process
    if (isset($_POST['register'])) {
        $name = trim($_POST['name']);
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT); // Hash the password

        // Check if the username or email already exists
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $register_error = "Username or email already exists.";
        } else {
            // Insert new user into the database
            $stmt = $conn->prepare("INSERT INTO users (name, username, email, password) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $name, $username, $email, $password);
            if ($stmt->execute()) {
                $_SESSION['username'] = $username;
                // Redirect to sign-in container
                header("Location: login.php");
            } else {
                $register_error = "Registration failed. Please try again.";
            }
        }
    }

    // Login process
    if (isset($_POST['login'])) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        // Check credentials
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['username'] = $user['username'];
                header("Location: product.php"); // Redirect to product page after successful login
                exit();
            } else {
                $login_error = "Invalid username or password.";
            }
        } else {
            $login_error = "Invalid username or password.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login</title>
    <!-- font awesome icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css" integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- css stylesheet -->
    <link rel="stylesheet" href="dist/css/login-styles.css">
</head>

<body>

    <div class="container" id="container">
        <div class="form-container sign-up-container">
            <form id="registerForm" action="" method="POST"> 
                <h1>Create Account</h1>
                <div class="infield">
                    <input type="text" placeholder="Name" name="name" id="registerName"/> 
                    <label></label>
                </div>
                <div class="infield">
                    <input type="text" placeholder="Username" name="username" id="registerUname"/> 
                    <label></label>
                </div>
                <div class="infield">
                    <input type="email" placeholder="Email" name="email" id="registerEmail"/> 
                    <label></label>
                </div>
                <div class="infield">
                    <input type="password" placeholder="Password" name="password" id="registerPsw"/> 
                    <label></label>
                </div>
                <button type="submit" name="register">Sign Up</button> 
            </form>
        </div>
        <div class="form-container sign-in-container">
            <form id="loginForm" action="" method="POST"> 
                <h1>Sign in</h1>
                <div class="infield">
                    <input type="text" placeholder="Username" name="username" id="loginUname"/> 
                    <label></label>
                </div>
                <div class="infield">
                    <input type="password" placeholder="Password" name="password" id="loginPsw"/> 
                    <label></label>
                </div>
                <button type="submit" name="login">Sign In</button> 
            </form>
        </div>
        <div class="overlay-container" id="overlayCon">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h1>Welcome Back!</h1>
                    <p>To keep connected with us please login with your personal info</p>
                    <button>Sign In</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <h1>Hello, Friend!</h1>
                    <p>Enter your personal details and start your journey with us</p>
                    <button>Sign Up</button>
                </div>
            </div>
            <button id="overlayBtn"></button>
        </div>
    </div>

    <footer>
    </footer>
    
    <!-- js code -->
    <script src="dist/js/formValidation.js"></script>
    
    <script>
        const container = document.getElementById('container');
        const overlayCon = document.getElementById('overlayCon');
        const overlayBtn = document.getElementById('overlayBtn');

        overlayBtn.addEventListener('click', ()=> {
            container.classList.toggle('right-panel-active');

            overlayBtn.classList.remove('btnScaled');
            window.requestAnimationFrame(() => {
                overlayBtn.classList.add('btnScaled');
            });
        });
    </script>
</body>
</html>
